from mypackage import power, average, SayHello
SayHello("Chand")
x=average(37426,28748262)
print("average(37426,28748262) : ", x)
